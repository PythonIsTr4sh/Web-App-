const CACHE_NAME = "puzzle-cache-v1";

const ASSETS = [
    "Puzzle/index.html",
"Puzzle/style.css",
"Puzzle/script.js",
"Puzzle/manifest.json",
"Puzzle/image/icon.png"
];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
    );
});

self.addEventListener("fetch", (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => response || fetch(event.request))
    );
});
