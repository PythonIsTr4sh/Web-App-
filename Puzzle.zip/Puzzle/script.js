// Registrazione del Service Worker per la PWA
// =============================================================
// Controlla se il browser supporta i Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js')
    .then(() => console.log("Service Worker registrato!"))
    .catch(err => console.log("Errore nella registrazione del Service Worker:", err));
}

// Reindirizzamento da HTTP a HTTPS
// =============================================================
// Se il protocollo della pagina è HTTP...
if(location.protocol=="http:"){
    location.href="https"+location.href.substring(4);
}

// Selezione degli elementi HTML e dichiarazione delle variabili globali
// =============================================================
// Elementi HTML principali del gioco
const puzzleContainer = document.getElementById('puzzle');        // Contenitore dove verrà creato il puzzle
const shuffleButton = document.getElementById('shuffle');           // Bottone per mescolare il puzzle
const gridSizeSelector = document.getElementById('gridSize');       // Selettore per la dimensione della griglia (es. 3x3, 4x4)
const restartButton = document.getElementById('restart');           // Bottone per riavviare il gioco dopo averlo completato
const uploadButton = document.getElementById('uploadButton');       // Bottone per caricare un'immagine dal computer
const fileInput = document.getElementById('fileInput');             // Input file nascosto per la selezione dell'immagine

// Variabili per gestire lo stato del gioco
let pieces = [];                // Array che conterrà i pezzi del puzzle
let selectedPiece = null;       // Memorizza il pezzo selezionato dall'utente per effettuare uno scambio
let imageUrl = "";              // URL dell'immagine usata per il puzzle; inizialmente vuoto
let finishGame = false;         // Flag che indica se il gioco è terminato
let currentObjectURL = null;    // URL oggetto della immagine caricata, utile per gestire la memoria
let timerInterval = null;       // Riferimento all'intervallo del timer per aggiornarlo
let startTime = null;           // Momento in cui il gioco è iniziato
let elapsedTime = 0;            // Tempo trascorso dall'inizio del gioco (in secondi)

// Creazione e configurazione del display del timer
// =============================================================
// Crea un nuovo elemento div che mostrerà il timer
const timerDisplay = document.createElement('div');
timerDisplay.id = 'timer';
// Inserisce il display del timer all'inizio del contenitore principale ('.container')
document.querySelector('.container').prepend(timerDisplay);

// Funzione: createPuzzle(gridSize)
// Descrizione: Crea il puzzle basato sulla dimensione della griglia scelta
// Parametro: gridSize - numero di pezzi per lato della griglia (es. 3 per un puzzle 3x3)
// =============================================================
function createPuzzle(gridSize) {
    // Resetta il timer per una nuova partita
    clearTimer();
    // Svuota l'array dei pezzi e il contenuto del contenitore HTML
    pieces = [];
    puzzleContainer.innerHTML = '';

    // Calcola la dimensione (in pixel) di ogni pezzo in base ad un'area totale di 400px
    const pieceSize = 400 / gridSize;
    // Imposta il layout del contenitore usando CSS Grid
    puzzleContainer.style.gridTemplateColumns = `repeat(${gridSize}, ${pieceSize}px)`;
    puzzleContainer.style.gridTemplateRows = `repeat(${gridSize}, ${pieceSize}px)`;

    // Ciclo per creare tutti i pezzi del puzzle
    for (let i = 0; i < gridSize * gridSize; i++) {
        // Crea un nuovo elemento div per il pezzo
        let piece = document.createElement('div');
        // Imposta l'immagine di sfondo usando l'URL dell'immagine scelta
        piece.style.backgroundImage = `url(${imageUrl})`;
        // Imposta la dimensione complessiva dell'immagine di sfondo (per coprire l'intera griglia)
        piece.style.backgroundSize = `${gridSize * pieceSize}px ${gridSize * pieceSize}px`;
        // Posiziona correttamente l'immagine di sfondo in modo da mostrare solo la parte corrispondente al pezzo
        piece.style.backgroundPosition = `${(i % gridSize) * -pieceSize}px ${(Math.floor(i / gridSize)) * -pieceSize}px`;
        // Imposta la larghezza e l'altezza del pezzo
        piece.style.width = `${pieceSize}px`;
        piece.style.height = `${pieceSize}px`;
        // Utilizza la proprietà CSS "order" per gestire l'ordine dei pezzi nella griglia
        piece.style.order = i;
        // Assegna un attributo "data-index" che memorizza la posizione originale del pezzo
        piece.setAttribute('data-index', i);
        // Aggiunge un listener per il click sul pezzo, che richiama la funzione selectPiece
        piece.addEventListener('click', selectPiece);
        // Aggiunge il pezzo al contenitore del puzzle
        puzzleContainer.appendChild(piece);
        // Aggiunge il pezzo all'array globale dei pezzi
        pieces.push(piece);
    }
}

// Funzione: clearTimer()
// Descrizione: Ferma e resetta il timer, ripulendo il display
// =============================================================
function clearTimer() {
    // Se esiste un intervallo attivo, lo cancella
    if(timerInterval) clearInterval(timerInterval);
    timerInterval = null;
    // Reset del tempo trascorso
    elapsedTime = 0;
    // Pulisce il contenuto del display del timer
    timerDisplay.textContent = '';
}

// Funzione: shufflePuzzle()
// Descrizione: Mescola casualmente i pezzi del puzzle e avvia il timer
// =============================================================
function shufflePuzzle() {
    // Resetta il timer per iniziare una nuova partita
    clearTimer();
    // Imposta il tempo di inizio del gioco al momento corrente
    startTime = Date.now();
    
    // Avvia un intervallo che aggiorna il display del timer ogni secondo
    timerInterval = setInterval(() => {
        // Calcola il tempo trascorso in secondi
        elapsedTime = Math.floor((Date.now() - startTime) / 1000);
        // Aggiorna il display del timer con il tempo formattato
        timerDisplay.textContent = `Tempo: ${formatTime(elapsedTime)}`;
    }, 1000);

    // Crea una copia dell'array dei pezzi per poterli mescolare
    let shuffledPieces = pieces.slice();
    // Mescola i pezzi in modo casuale
    shuffledPieces.sort(() => Math.random() - 0.5);

    // Applica il nuovo ordine mescolato a ciascun pezzo
    shuffledPieces.forEach((piece, index) => {
        piece.style.order = index;
    });

    // Resetta il pezzo selezionato e rimuove eventuali bordi evidenziati
    selectedPiece = null;
    pieces.forEach(piece => piece.style.border = "");
}

// Funzione: selectPiece(event)
// Descrizione: Gestisce la selezione e lo scambio di due pezzi del puzzle
// Parametro: event - l'evento di click sul pezzo
// =============================================================
function selectPiece(event) {
    // Recupera il pezzo cliccato
    const clickedPiece = event.target;

    // Se nessun pezzo è attualmente selezionato...
    if (!selectedPiece) {
        // ...seleziona il pezzo cliccato e evidenzialo con un bordo blu
        selectedPiece = clickedPiece;
        clickedPiece.style.border = "2px solid blue";
    } else {
        // Se un pezzo è già selezionato, scambia l'ordine (proprietà CSS "order") tra il pezzo selezionato e quello cliccato
        const tempOrder = clickedPiece.style.order;
        clickedPiece.style.order = selectedPiece.style.order;
        selectedPiece.style.order = tempOrder;

        // Rimuove l'evidenziazione (bordo blu) da tutti i pezzi
        pieces.forEach(piece => piece.style.border = "");
        // Resetta la variabile selectedPiece per permettere una nuova selezione
        selectedPiece = null;

        // Controlla se il puzzle è stato completato dopo lo scambio
        checkWin();
    }
}

// Funzione: formatTime(seconds)
// Descrizione: Converte il tempo in secondi in un formato "mm:ss"
// Parametro: seconds - il tempo totale in secondi
// =============================================================
function formatTime(seconds) {
    // Calcola i minuti e i secondi residui
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    // Ritorna il tempo formattato con due cifre per minuti e secondi
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Funzione: checkWin()
// Descrizione: Verifica se i pezzi del puzzle sono nella posizione corretta
// =============================================================
function checkWin() {
    // Controlla che ogni pezzo sia al posto giusto confrontando il valore della proprietà "order"
// con il valore originale memorizzato in "data-index"
    const isComplete = pieces.every(piece => parseInt(piece.style.order) === parseInt(piece.getAttribute('data-index')));
    if (isComplete) {
        // Se il puzzle è completato, interrompe l'aggiornamento del timer
        clearInterval(timerInterval);
        // Mostra il tempo impiegato a completare il puzzle in un elemento HTML con id "tempoTOT"
        document.getElementById('tempoTOT').innerHTML = `
            <p>Tempo impiegato: ${formatTime(elapsedTime)}</p>    
        `;
        // Visualizza il messaggio di completamento (elemento con id "finish")
        document.getElementById('finish').style.display = 'block';
        // Imposta il flag di fine gioco a true
        finishGame = true;
    }
}

// Gestione dell'upload dell'immagine
// =============================================================
// Quando l'utente clicca sul bottone "Carica immagine", simula un click sull'input file
uploadButton.addEventListener('click', () => {
    fileInput.click();
});

// Quando l'utente seleziona un file immagine...
fileInput.addEventListener('change', function (e) {
    // Ottiene il primo file selezionato
    const file = e.target.files[0];
    if (file) {
        // Se esiste già un URL oggetto creato in precedenza, lo revoca per liberare risorse
        if (currentObjectURL) URL.revokeObjectURL(currentObjectURL);
        // Crea un nuovo URL oggetto per il file selezionato
        currentObjectURL = URL.createObjectURL(file);
        // Aggiorna l'URL dell'immagine da usare per il puzzle
        imageUrl = currentObjectURL;
        // Ricrea il puzzle con la dimensione attuale della griglia
        createPuzzle(parseInt(gridSizeSelector.value));
    }
});

// Gestione del selettore della dimensione della griglia
// =============================================================
// Quando l'utente cambia il valore del selettore, il puzzle viene ricreato con la nuova dimensione
gridSizeSelector.addEventListener('change', (event) => {
    const gridSize = parseInt(event.target.value);
    createPuzzle(gridSize);
});

// Gestione del bottone "Rifai" (riavvio del gioco)
// =============================================================
// Aggiunge un event listener sul bottone "Rifai" che si trova all'interno dell'elemento con id "finish"
restartButton.closest('#finish').addEventListener('click', (e) => {
    // Verifica che il click provenga effettivamente dal bottone con id "restart"
    if(e.target.id === 'restart') {
        // Nasconde il messaggio di fine gioco
        document.getElementById('finish').style.display = 'none';
        // Resetta il flag di fine gioco
        finishGame = false;
        // Mescola i pezzi per iniziare una nuova partita
        shufflePuzzle();
    }
});

// Gestione del bottone "Mescola"
// =============================================================
// Quando l'utente clicca sul bottone "Mescola", viene eseguita la funzione shufflePuzzle per mescolare i pezzi
shuffleButton.addEventListener('click', shufflePuzzle);
